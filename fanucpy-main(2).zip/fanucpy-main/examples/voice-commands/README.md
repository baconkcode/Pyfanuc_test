# Voice Command for FanucPy

This is a very early attempt to program and control industrial robots with spoken human language using OpenAI Whisper and OpenAI ChatGPT.

### Usage

Check demo.py (demo video) and use with CAUTION!!!